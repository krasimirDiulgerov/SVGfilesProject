#pragma once
#include"figure.h"

class ArrayWithFigures {
private:
	int capacity=2;
	int size = 0;
	void erase();
	Figure* array = new Figure[capacity];
public:
	Figure* getArrayWithFigures()const;
	void resize();
	int getsize();
	int getcapacity();
	void pushNewFigure(Figure&);


};
