//circle
//rektangle
//line
#include<iostream>


class Figure {
private:
	int startingPointX;
	int startingPointY;
	 char color[3];
public:
	int getStartingPointX()const;
	int getStartingPointY()const;
	void setStartingPointX(int);
	void setStartingPointY(int);
	void setColor(char*);
	Figure();
	Figure& operator=(Figure&);


};


class Circle:public Figure {
private:
	char type[10] = "Circle";
	int radius;
public:
	Circle();
	Circle(int, int, int, char*);
	
};

class Rectangle :public Figure {
private:
	char type[10] = "Rectangle";
	int width;
	int height;

public:
	Rectangle();
	Rectangle(int, int, int, int, char*);
};

class Line :public Figure {
private:
	char type[10] = "Line";
	int finalPointX;
	int finalPointY;
public:
	Line();
	Line(int, int, int, int, char*);
};
