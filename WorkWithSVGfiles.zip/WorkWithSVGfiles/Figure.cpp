#include"figure.h"

Figure::Figure() {
	startingPointX = 0;
	startingPointY = 0;
	strcpy(color, "unknown");
}

int Figure::getStartingPointX()const {
	return startingPointX;
}

int Figure::getStartingPointY()const {
	return startingPointY;
}

void Figure::setStartingPointX(int X) {
	startingPointX = X;
}

void Figure::setStartingPointY(int Y) {
	startingPointY = Y;
}

void Figure::setColor(char* color_) {
	strcpy(color, color_);
}

Figure& Figure:: operator=(Figure& other) {
	startingPointX = other.startingPointX;
	startingPointY = other.startingPointY;
	strcpy(color, other.color);

}

Circle::Circle() {
	Figure();
	radius = 0;
}

Circle::Circle(int spX,int spY,int radius,char* color) {
	setStartingPointX(spX);
	setStartingPointY(spY);
	setColor(color);
	this->radius = radius;
}

Rectangle::Rectangle() {
	Figure();
	width = 0;
	height = 0;
}

Rectangle::Rectangle(int spX, int spY, int Width, int Height, char* color) {
	setStartingPointX(spX);
	setStartingPointY(spY);
	setColor(color);
	width = Width;
	height = Height;
}

Line::Line() {
	Figure();
	finalPointX = 0;
	finalPointY = 0;

}

Line::Line(int spX, int spY,int epX,int  epY,char* color) {
	setStartingPointX(spX);
	setStartingPointY(spY);
	setColor(color);
	finalPointX = epX;
	finalPointY = epY;
}